#!/bin/bash

mvn exec:java@compute_all
