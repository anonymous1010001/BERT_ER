/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.evaluator;

/**
 *
 * @author suchana
 */

public enum MetricCutOff {
    AP_10,
    AP_100,
    AP_1000,
    Recall_10,
    Recall_100,
    Recall_1000,
    nDCG_10,
    nDCG_100,
    nDCG_1000
}
