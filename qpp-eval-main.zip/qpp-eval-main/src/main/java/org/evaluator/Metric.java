package org.evaluator;

public enum Metric {
    AP,
    P_10,
    Recall,
    nDCG
}
