/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.experiments;

/**
 *
 * @author suchana
 */

public class RerankedDocInfo {
    
    public String qid;
    public String docid;
    public String docScore;

    public String getQid() {
        return qid;
    }

    public void setQid(String qid) {
        this.qid = qid;
    }

    public String getDocid() {
        return docid;
    }

    public void setDocid(String docid) {
        this.docid = docid;
    }

    public String getDocScore() {
        return docScore;
    }

    public void setDocScore(String docScore) {
        this.docScore = docScore;
    }
    
    
}
