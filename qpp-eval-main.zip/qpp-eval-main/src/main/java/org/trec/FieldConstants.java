package org.trec;

public class FieldConstants {
    public static final String FIELD_ANALYZED_CONTENT = "words";
    public static final String FIELD_ID = "id";
}
