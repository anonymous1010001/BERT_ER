mvn exec:java -Dexec.mainClass="indexing.MsMarcoIndexer"
